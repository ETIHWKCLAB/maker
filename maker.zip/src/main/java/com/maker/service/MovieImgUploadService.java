package com.maker.service;

public class MovieImgUploadService {

}
