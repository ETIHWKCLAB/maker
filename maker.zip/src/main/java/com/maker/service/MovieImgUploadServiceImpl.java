package com.maker.service;

public interface MovieImgUploadServiceImpl {

}
